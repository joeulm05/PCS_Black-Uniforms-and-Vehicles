# Black Uniforms and Police Cars v1.2.0

Black officer uniforms for 18 supplied variants, Chief white shirt and black pants
with matching first-person sleeves, and black vanilla police-car bodywork with
white Winston Springs Police lettering.

Choose one complete download:
- **Installer:** extract fully and run Install_Black_Uniforms_and_Cars.bat with the game closed.
- **Manual:** extract and follow README.txt to copy the twelve texture files.

Fresh installations and updates use the same full download. UE4SS is not required.
This packaging refresh includes the previously audited installer and adds a script-free
manual download. Texture content and gameplay behavior are unchanged. SHA256SUMS.txt
provides archive checksums. No new in-game testing is claimed for this repackaging.

Other mods replacing the same textures can conflict. Modern Policing replaces the
vanilla vehicle model, so this mod's vanilla-car recolor may not be visible with it.
