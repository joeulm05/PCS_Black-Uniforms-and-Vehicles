# Black Uniforms and Police Cars | Author: Joe "Gambit" Bradford
import argparse
import hashlib
import json
import re
import shutil
import struct
import subprocess
import zipfile
from pathlib import Path
import numpy as np
from scipy import ndimage
from PIL import Image
from build_mod import write_job, hash_name, chunk_id, container_header
from decode_vt import decode, metadata


def regions(rgb):
    r,g,b=rgb.astype(np.float32).transpose(2,0,1)
    shirt=(r>45)&(g>65)&(b>85)&(g>r*1.07)&(b>r*1.20)
    navy=(r<70)&(g<80)&(b>12)&(b<120)&(b>r*1.30)&(b>g*1.20)
    labels,_=ndimage.label(shirt)
    sizes=np.bincount(labels.ravel());sizes[0]=0
    mask=(sizes[labels]>20000).astype(np.uint8)
    pants,_=ndimage.label(navy)
    counts=np.bincount(pants.ravel());counts[0]=0
    largest=int(np.argmax(counts))
    assert counts[largest]>1000000 and np.count_nonzero(counts>500000)==1
    mask[pants==largest]=2
    assert np.count_nonzero(mask==1)>200000
    patches=shirt&(sizes[labels]>1000)&(sizes[labels]<=20000)
    gold=(r>140)&(g>80)&(b<r*.7)
    return mask,patches,gold,navy


def main():
    p=argparse.ArgumentParser()
    p.add_argument('archive',type=Path)
    p.add_argument('output',type=Path)
    p.add_argument('--retoc',required=True)
    p.add_argument('--empty-pak',type=Path,required=True)
    a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
    base=Path(__file__).resolve().parent
    exe=a.output/'recolor_assets'
    subprocess.run(['cc','-O2','-Wall','-Wextra',str(base/'recolor_assets.c'),'-lm','-o',str(exe)],check=True)
    work=a.output/'work';work.mkdir(exist_ok=True)
    chunks=a.output/'raw'/'chunks';chunks.mkdir(parents=True,exist_ok=True)
    paths={};ids=[];report=[]
    with zipfile.ZipFile(a.archive) as z:
        names=sorted(n for n in z.namelist() if re.search(r'/Worker_0[789]_[FM]/',n) and n.endswith(('__meshes_Merge_0_Diffuse.uasset','__meshes_Merge_1_Diffuse.uasset')))
        assert len(names)==7
        for name in names:
            key=re.search(r'(Worker_0[789]_[FM])/',name)[1]+'_'+Path(name).stem
            original=z.read(name);bulk=z.read(name[:-7]+'.ubulk')
            rgb=np.array(decode(original,bulk)[0]);m=metadata(original)
            mask,patches,gold,navy=regions(rgb)
            job=work/(key+'.bin');write_job(job,m,4,[])
            jobmask=mask.copy();jobmask[patches]=3
            with job.open('ab') as f:f.write(jobmask.tobytes())
            old=work/(key+'.old');new=work/(key+'.ubulk');old.write_bytes(bulk)
            result=subprocess.run([str(exe),str(job),str(old),str(new)],capture_output=True,text=True,check=True)
            patched=new.read_bytes();asset=original;offset=0;allowed=np.zeros(len(asset),bool)
            for c in m['chunks']:
                digest=hashlib.sha1(bulk[offset:offset+c['size']]).digest()
                assert digest.hex()==c['hash'] and asset.count(digest)==1
                at=asset.index(digest);allowed[at:at+20]=True
                asset=asset.replace(digest,hashlib.sha1(patched[offset:offset+c['size']]).digest());offset+=c['size']
            assert offset==len(bulk)==len(patched)
            image,_=decode(asset,patched);after=np.array(image)
            linear=after.astype(np.float32)/255
            linear=np.where(linear<=.04045,linear/12.92,((linear+.055)/1.055)**2.4)
            fallback=[float(x) for x in linear.mean(axis=(0,1),dtype=np.float64)]+[1.0]
            asset=bytearray(asset);struct.pack_into('<4f',asset,m['fallback_offset'],*fallback);asset=bytes(asset)
            allowed[m['fallback_offset']:m['fallback_offset']+16]=True
            assert np.array_equal(np.frombuffer(original,np.uint8)[~allowed],np.frombuffer(asset,np.uint8)[~allowed])
            changed=np.any(rgb!=after,axis=2)
            assert not changed[gold].any(),key+' gold changed'
            assert not changed[patches].any(),key+' patch changed'
            protected=navy&~ndimage.binary_dilation(mask!=0,iterations=6)
            assert not changed[protected].any(),key+' protected navy changed'
            stats={}
            for region,label in [(1,'shirt'),(2,'pants')]:
                mean=after[mask==region].mean(axis=0)
                assert mean.max()<35 and np.ptp(mean)<5,(key,label,mean)
                stats[label+'_mean_rgb']=mean.tolist()
            for mip in [3,5,7,m['mips']-1]:decode(asset,patched,mip)
            packages=re.findall(rb'/Game/[A-Za-z0-9_./]+',asset);assert len(packages)==1
            package=packages[0].decode();ident=hash_name(package);ids.append(ident)
            for kind,ext,data in [(1,'.uasset',asset),(2,'.ubulk',patched)]:
                cid=chunk_id(ident,kind);(chunks/cid).write_bytes(data)
                paths[cid]='../../../PoliceChiefSimulator/Content/'+package.removeprefix('/Game/')+ext
            image.resize((512,512)).save(work/(key+'.png'))
            report.append(dict(key=key,package=package,source_asset_sha256=hashlib.sha256(original).hexdigest(),source_bulk_sha256=hashlib.sha256(bulk).hexdigest(),gold_pixels_changed=0,patch_pixels_changed=0,protected_navy_pixels_changed=0,metadata_preserved=True,**stats,**json.loads(result.stdout)))
            print(key,stats,flush=True)
    stem='zz_PCS_Black_ExtraWorkers_P'
    (chunks/chunk_id(hash_name(stem),6)).write_bytes(container_header(stem,ids))
    (a.output/'raw'/'manifest.json').write_text(json.dumps(dict(chunk_paths=paths,version='RemovedOnDemandMetaData',mount_point='../../../'),indent=2))
    dest=a.output/'~mods';dest.mkdir(exist_ok=True)
    subprocess.run([a.retoc,'pack-raw',str(a.output/'raw'),str(dest/(stem+'.utoc'))],check=True)
    subprocess.run([a.retoc,'verify',str(dest/(stem+'.utoc'))],check=True)
    shutil.copyfile(a.empty_pak,dest/(stem+'.pak'))
    (a.output/'extra_workers_validation.json').write_text(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
