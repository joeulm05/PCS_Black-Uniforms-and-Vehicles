# v1.2.0

- Adds black shirts and pants for male and female workers 07, 08, and 09.
- Includes both clothing atlases used by Worker_07_F.
- Preserves badges, patches, and cap colors.
- Full installer adds the three new container files; existing v1.1.0 payload stays unchanged.

# Changelog

## 1.1.0

- Adds a white shirt and black pants for the player/Chief.
- Adds matching white first-person sleeves.
- Uses the Chief mesh geometry to isolate shirt and trousers from equipment.
- Includes the complete prior officer/car mod and adds the Chief containers.
- Installer upgrades the six-file release to all nine files.

## 1.0.0

- Adds black pants to match the black uniform shirts across all 12 officer variants.
- Preserves badges, patches, hats, and equipment.
- Includes the confirmed black police-car textures and white lettering unchanged.
- Adds a batch installer with automatic Steam discovery, file verification,
  backups, and rollback.
- Updates the earlier texture containers under their existing filenames.
- Includes separate player and GitHub source downloads. No UE4SS dependency.
