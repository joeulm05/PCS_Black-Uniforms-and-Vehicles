> Source package only. Download Installer or Manual from release Assets to install.

# Black Uniforms and Police Cars â€” v1.2.0

Author: Joe "Gambit" Bradford

Black uniform shirts and matching black pants for all 18 supplied male and female
officer variants. The player/Chief wears a white shirt and black pants, with matching
white first-person sleeves. Police cars have black bodywork with white Winston Springs
Police lettering. The normal and damaged car textures are included.

Badges, patches, hats, equipment, and vehicle mechanics retain their existing
appearance or behavior. This is a texture replacement mod. UE4SS is not required.

## Install or update

1. Close Police Chief Simulator.
2. Extract the entire player ZIP.
3. Double-click `Install_Black_Uniforms_and_Cars.bat`.

The installer finds the Steam installation automatically. If it cannot find a
unique installation, choose the game's executable in the file window. Existing
versions of these twelve texture files are backed up before replacement. Other
mods and UE4SS are preserved. No mods.txt edits or hotkeys are needed.

If Windows denies access to the game folder, right-click the batch file and
choose **Run as administrator**. The installer prints its log location if it fails.

For manual installation, copy the twelve files inside `Payload/~mods` into:

`Police Chief Simulator/PoliceChiefSimulator/Content/Paks/~mods`

Create `~mods` if it does not exist. Replace the older files with these same names.
Do not keep renamed copies of the old containers elsewhere in `Paks`.

## Remove

Close the game and remove only these files from `Content/Paks/~mods`:

- `zz_PCS_Black_Uniforms_P.pak`
- `zz_PCS_Black_Uniforms_P.utoc`
- `zz_PCS_Black_Uniforms_P.ucas`
- `zz_PCS_Black_PoliceCar_P.pak`
- `zz_PCS_Black_PoliceCar_P.utoc`
- `zz_PCS_Black_PoliceCar_P.ucas`
- `zz_PCS_Chief_Uniform_P.pak`
- `zz_PCS_Chief_Uniform_P.utoc`
- `zz_PCS_Chief_Uniform_P.ucas`

- `zz_PCS_Black_ExtraWorkers_P.pak`
- `zz_PCS_Black_ExtraWorkers_P.utoc`
- `zz_PCS_Black_ExtraWorkers_P.ucas`

To restore the previous version instead, copy its files back from your
download or the timestamped `PCS_Black_Uniforms_Backups` folder inside the
`PoliceChiefSimulator` project folder. A backup contains only files replaced
during that installation. Do not delete the whole `~mods` folder.

## Compatibility and validation

Other mods replacing the same officer diffuse textures or police-car body
textures can conflict. RoboCop's separate model and portrait containers are
not replaced by this installer. Game updates that change these texture assets
or their paths may require a mod update.

Version 1.2.0 adds seven clothing atlases covering Worker_07_F/M,
Worker_08_F/M, and Worker_09_F/M from the supplied game export. Existing
v1.1.0 containers remain byte-for-byte unchanged. New clothing textures are
checked for dark neutral shirt/pants colors, unchanged gold and blue patch
pixels at full resolution, preserved cap interiors, streaming mip readability,
asset metadata, and bulk hashes. Installer checks cover fresh install, upgrades,
reruns, backup, missing payload rejection, and rollback. The new officer
variants have not been tested in the Windows game here.

## Source

The GitHub source ZIP contains the installer and texture-processing source,
build instructions, and validation records. It excludes the game's artwork and
external tool binaries. It is not the player installer download; the player ZIP
contains the required `Payload/~mods` files.

See the separate Source download and GitHub release instructions.
